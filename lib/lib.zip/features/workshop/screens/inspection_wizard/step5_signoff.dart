import 'package:flutter/material.dart';

import '../../models/inspection_wizard_data.dart';

class Step5Signoff extends StatefulWidget {
  final InspectionWizardData data;
  final VoidCallback onPrevious;
  final Future<void> Function() onFinish;

  const Step5Signoff({
    super.key,
    required this.data,
    required this.onPrevious,
    required this.onFinish,
  });

  @override
  State<Step5Signoff> createState() =>
      _Step5SignoffState();
}

class _Step5SignoffState extends State<Step5Signoff> {
  final _formKey = GlobalKey<FormState>();

  late final TextEditingController
      _technicianController;

  late final TextEditingController
      _managerController;

  late final TextEditingController
      _technicianSignatureController;

  late final TextEditingController
      _managerSignatureController;

  late final TextEditingController
      _notesController;

  bool _saving = false;

  // ===========================================================================
  // SUMMARY
  // ===========================================================================

  int get _passed {
    return widget.data.checklistItems
        .where((item) => item.passed)
        .length;
  }

  int get _advisories {
    return widget.data.checklistItems
        .where((item) => item.advisoryOnly)
        .length;
  }

  int get _failed {
    return widget.data.checklistItems
        .where((item) => item.failed)
        .length;
  }

  int get _repairs {
    return widget.data.repairJobs.length;
  }

  double get _labourHours {
    return widget.data.repairJobs.fold(
      0,
      (total, job) =>
          total + job.estimatedHours,
    );
  }

  double get _estimatedCost {
    return widget.data.repairJobs.fold(
      0,
      (total, job) =>
          total + job.estimatedCost,
    );
  }

  int get _photos {
    return widget.data.checklistItems.fold(
      0,
      (total, item) =>
          total + item.photos.length,
    );
  }

  int get _notesCount {
    return widget.data.checklistItems
        .where(
          (item) =>
              item.notes.trim().isNotEmpty,
        )
        .length;
  }

  int get _score {
    final total =
        widget.data.checklistItems.length;

    if (total == 0) {
      return 0;
    }

    return ((_passed / total) * 100).round();
  }

  bool get _roadworthy => _failed == 0;

  // ===========================================================================
  // INIT
  // ===========================================================================

  @override
  void initState() {
    super.initState();

    _technicianController =
        TextEditingController(
      text: widget.data.technician ??
          widget.data.technicianName ??
          '',
    );

    _managerController =
        TextEditingController(
      text: widget.data.workshopManager ?? '',
    );

    _technicianSignatureController =
        TextEditingController(
      text:
          widget.data.technicianSignature ??
              widget.data.technician ??
              widget.data.technicianName ??
              '',
    );

    _managerSignatureController =
        TextEditingController(
      text:
          widget.data.managerSignature ?? '',
    );

    _notesController =
        TextEditingController(
      text: widget.data.finalNotes ?? '',
    );
  }

  // ===========================================================================
  // DISPOSE
  // ===========================================================================

  @override
  void dispose() {
    _technicianController.dispose();
    _managerController.dispose();
    _technicianSignatureController.dispose();
    _managerSignatureController.dispose();
    _notesController.dispose();

    super.dispose();
  }

  // ===========================================================================
  // FINISH
  // ===========================================================================

  Future<void> _finishInspection() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    widget.data.technician =
        _technicianController.text.trim();

    widget.data.technicianName =
        _technicianController.text.trim();

    widget.data.workshopManager =
        _managerController.text.trim();

    widget.data.technicianSignature =
        _technicianSignatureController
            .text
            .trim();

    widget.data.managerSignature =
        _managerSignatureController
            .text
            .trim();

    widget.data.finalNotes =
        _notesController.text.trim();

    widget.data.notes =
        _notesController.text.trim();

    setState(() {
      _saving = true;
    });

    try {
      await widget.onFinish();
    } finally {
      if (mounted) {
        setState(() {
          _saving = false;
        });
      }
    }
  }

  // ===========================================================================
  // BUILD
  // ===========================================================================

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;

    return Form(
      key: _formKey,
      child: Column(
        children: [
          // ===================================================================
          // HEADER
          // ===================================================================

          Container(
            padding: const EdgeInsets.fromLTRB(
              24,
              20,
              24,
              18,
            ),
            decoration: BoxDecoration(
              color: scheme.surface,
              border: Border(
                bottom: BorderSide(
                  color: scheme.outlineVariant,
                ),
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    color:
                        scheme.primaryContainer,
                    borderRadius:
                        BorderRadius.circular(14),
                  ),
                  child: Icon(
                    Icons.fact_check_outlined,
                    color: scheme.primary,
                    size: 28,
                  ),
                ),

                const SizedBox(width: 14),

                Expanded(
                  child: Column(
                    crossAxisAlignment:
                        CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Final Inspection Sign-off',
                        style: theme.textTheme
                            .headlineSmall
                            ?.copyWith(
                          fontWeight:
                              FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        'Review and complete the inspection.',
                        style: theme.textTheme
                            .bodyMedium
                            ?.copyWith(
                          color:
                              scheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // ===================================================================
          // CONTENT
          // ===================================================================

          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                // =============================================================
                // VEHICLE
                // =============================================================

                _SectionCard(
                  title: 'Vehicle',
                  icon:
                      Icons.directions_car_outlined,
                  child: Wrap(
                    spacing: 24,
                    runSpacing: 16,
                    children: [
                      _Detail(
                        label: 'Registration',
                        value:
                            widget.data.registration
                                    ?.isNotEmpty ==
                                true
                            ? widget.data
                                .registration!
                            : 'Not specified',
                      ),
                      _Detail(
                        label: 'Fleet Number',
                        value:
                            widget.data.fleetNumber
                                    ?.isNotEmpty ==
                                true
                            ? widget.data
                                .fleetNumber!
                            : 'Not specified',
                      ),
                      _Detail(
                        label: 'Mileage',
                        value:
                            widget.data.mileage !=
                                    null
                            ? '${widget.data.mileage} miles'
                            : 'Not specified',
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 16),

                // =============================================================
                // INSPECTION RESULT
                // =============================================================

                _ResultCard(
                  score: _score,
                  passed: _passed,
                  advisories: _advisories,
                  failed: _failed,
                  roadworthy: _roadworthy,
                ),

                const SizedBox(height: 16),

                // =============================================================
                // REPAIRS
                // =============================================================

                _SectionCard(
                  title: 'Repair Summary',
                  icon:
                      Icons.build_outlined,
                  child: Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: [
                      _SummaryChip(
                        icon:
                            Icons.build_outlined,
                        label: 'Repairs',
                        value:
                            '$_repairs',
                      ),
                      _SummaryChip(
                        icon:
                            Icons.schedule_outlined,
                        label: 'Labour',
                        value:
                            '${_labourHours.toStringAsFixed(1)} hrs',
                      ),
                      _SummaryChip(
                        icon:
                            Icons.payments_outlined,
                        label: 'Estimated',
                        value:
                            '£${_estimatedCost.toStringAsFixed(2)}',
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 16),

                // =============================================================
                // EVIDENCE
                // =============================================================

                _SectionCard(
                  title: 'Inspection Evidence',
                  icon:
                      Icons.attach_file_outlined,
                  child: Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: [
                      _SummaryChip(
                        icon:
                            Icons.photo_outlined,
                        label: 'Photos',
                        value:
                            '$_photos',
                      ),
                      _SummaryChip(
                        icon:
                            Icons.notes_outlined,
                        label: 'Checklist Notes',
                        value:
                            '$_notesCount',
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                // =============================================================
                // TECHNICIAN
                // =============================================================

                _SectionCard(
                  title: 'Technician Sign-off',
                  icon:
                      Icons.engineering_outlined,
                  child: Column(
                    crossAxisAlignment:
                        CrossAxisAlignment.stretch,
                    children: [
                      TextFormField(
                        controller:
                            _technicianController,
                        decoration:
                            const InputDecoration(
                          labelText:
                              'Technician',
                          prefixIcon:
                              Icon(
                            Icons.person_outline,
                          ),
                          border:
                              OutlineInputBorder(),
                        ),
                        validator: (value) {
                          if (value == null ||
                              value
                                  .trim()
                                  .isEmpty) {
                            return 'Enter technician name';
                          }

                          return null;
                        },
                      ),

                      const SizedBox(height: 14),

                      TextFormField(
                        controller:
                            _technicianSignatureController,
                        textCapitalization:
                            TextCapitalization.words,
                        decoration:
                            const InputDecoration(
                          labelText:
                              'Technician Signature',
                          hintText:
                              'Type your full name as your signature',
                          prefixIcon:
                              Icon(
                            Icons.draw_outlined,
                          ),
                          border:
                              OutlineInputBorder(),
                        ),
                        validator: (value) {
                          if (value == null ||
                              value
                                  .trim()
                                  .isEmpty) {
                            return 'Enter technician signature';
                          }

                          return null;
                        },
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 16),

                // =============================================================
                // MANAGER
                // =============================================================

                _SectionCard(
                  title:
                      'Workshop Manager Sign-off',
                  icon:
                      Icons.manage_accounts_outlined,
                  child: Column(
                    crossAxisAlignment:
                        CrossAxisAlignment.stretch,
                    children: [
                      TextFormField(
                        controller:
                            _managerController,
                        decoration:
                            const InputDecoration(
                          labelText:
                              'Workshop Manager',
                          prefixIcon:
                              Icon(
                            Icons.person_outline,
                          ),
                          border:
                              OutlineInputBorder(),
                        ),
                      ),

                      const SizedBox(height: 14),

                      TextFormField(
                        controller:
                            _managerSignatureController,
                        textCapitalization:
                            TextCapitalization.words,
                        decoration:
                            const InputDecoration(
                          labelText:
                              'Manager Signature',
                          hintText:
                              'Type full name as signature',
                          prefixIcon:
                              Icon(
                            Icons.draw_outlined,
                          ),
                          border:
                              OutlineInputBorder(),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 16),

                // =============================================================
                // FINAL NOTES
                // =============================================================

                _SectionCard(
                  title: 'Final Notes',
                  icon:
                      Icons.notes_outlined,
                  child: TextFormField(
                    controller:
                        _notesController,
                    minLines: 4,
                    maxLines: 8,
                    textCapitalization:
                        TextCapitalization.sentences,
                    decoration:
                        const InputDecoration(
                      labelText:
                          'Final inspection notes',
                      hintText:
                          'Add any final comments before completing the inspection...',
                      alignLabelWithHint: true,
                      border:
                          OutlineInputBorder(),
                    ),
                  ),
                ),

                const SizedBox(height: 20),

                // =============================================================
                // FINAL WARNING
                // =============================================================

                if (!_roadworthy)
                  Container(
                    padding:
                        const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color:
                          scheme.errorContainer,
                      borderRadius:
                          BorderRadius.circular(16),
                      border: Border.all(
                        color: scheme.error
                            .withValues(
                          alpha: 0.35,
                        ),
                      ),
                    ),
                    child: Row(
                      crossAxisAlignment:
                          CrossAxisAlignment.start,
                      children: [
                        Icon(
                          Icons
                              .warning_amber_rounded,
                          color:
                              scheme.error,
                          size: 28,
                        ),
                        const SizedBox(
                          width: 12,
                        ),
                        Expanded(
                          child: Column(
                            crossAxisAlignment:
                                CrossAxisAlignment
                                    .start,
                            children: [
                              Text(
                                'Vehicle Not Roadworthy',
                                style: theme
                                    .textTheme
                                    .titleMedium
                                    ?.copyWith(
                                  fontWeight:
                                      FontWeight
                                          .w800,
                                  color: scheme
                                      .onErrorContainer,
                                ),
                              ),
                              const SizedBox(
                                height: 4,
                              ),
                              Text(
                                'This inspection contains '
                                '$_failed defect${_failed == 1 ? '' : 's'}. '
                                'Please review the repair requirements '
                                'before completing the inspection.',
                                style: theme
                                    .textTheme
                                    .bodyMedium
                                    ?.copyWith(
                                  color: scheme
                                      .onErrorContainer,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                const SizedBox(height: 20),
              ],
            ),
          ),

          // ===================================================================
          // FOOTER
          // ===================================================================

          Container(
            padding:
                const EdgeInsets.symmetric(
              horizontal: 24,
              vertical: 16,
            ),
            decoration: BoxDecoration(
              color: scheme.surface,
              border: Border(
                top: BorderSide(
                  color:
                      scheme.outlineVariant,
                ),
              ),
            ),
            child: Wrap(
              alignment:
                  WrapAlignment.spaceBetween,
              spacing: 12,
              runSpacing: 12,
              children: [
                OutlinedButton.icon(
                  onPressed: _saving
                      ? null
                      : widget.onPrevious,
                  icon: const Icon(
                    Icons.arrow_back_rounded,
                  ),
                  label:
                      const Text('Back'),
                ),

                FilledButton.icon(
                  onPressed: _saving
                      ? null
                      : _finishInspection,
                  icon: _saving
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child:
                              CircularProgressIndicator(
                            strokeWidth: 2,
                          ),
                        )
                      : const Icon(
                          Icons.check_circle_outline,
                        ),
                  label: Text(
                    _saving
                        ? 'Saving...'
                        : 'Complete Inspection',
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// =============================================================================
// SECTION CARD
// =============================================================================

class _SectionCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final Widget child;

  const _SectionCard({
    required this.title,
    required this.icon,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: scheme.surface,
        borderRadius:
            BorderRadius.circular(18),
        border: Border.all(
          color: scheme.outlineVariant,
        ),
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Icon(
                icon,
                color: scheme.primary,
              ),
              const SizedBox(width: 8),
              Text(
                title,
                style: theme.textTheme
                    .titleLarge
                    ?.copyWith(
                  fontWeight:
                      FontWeight.w800,
                ),
              ),
            ],
          ),

          const SizedBox(height: 16),

          child,
        ],
      ),
    );
  }
}

// =============================================================================
// VEHICLE DETAIL
// =============================================================================

class _Detail extends StatelessWidget {
  final String label;
  final String value;

  const _Detail({
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 220,
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: Theme.of(context)
                .textTheme
                .bodySmall
                ?.copyWith(
              color: Theme.of(context)
                  .colorScheme
                  .onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            value,
            style: const TextStyle(
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

// =============================================================================
// RESULT CARD
// =============================================================================

class _ResultCard extends StatelessWidget {
  final int score;
  final int passed;
  final int advisories;
  final int failed;
  final bool roadworthy;

  const _ResultCard({
    required this.score,
    required this.passed,
    required this.advisories,
    required this.failed,
    required this.roadworthy,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: scheme.surface,
        borderRadius:
            BorderRadius.circular(18),
        border: Border.all(
          color: roadworthy
              ? scheme.primary
                  .withValues(alpha: 0.35)
              : scheme.error
                  .withValues(alpha: 0.4),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 78,
            height: 78,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: roadworthy
                  ? scheme.primaryContainer
                  : scheme.errorContainer,
            ),
            child: Center(
              child: Text(
                '$score%',
                style: theme.textTheme
                    .titleLarge
                    ?.copyWith(
                  fontWeight:
                      FontWeight.w900,
                  color: roadworthy
                      ? scheme.primary
                      : scheme.error,
                ),
              ),
            ),
          ),

          const SizedBox(width: 18),

          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  roadworthy
                      ? 'Vehicle Roadworthy'
                      : 'Vehicle Not Roadworthy',
                  style: theme.textTheme
                      .titleLarge
                      ?.copyWith(
                    fontWeight:
                        FontWeight.w800,
                  ),
                ),

                const SizedBox(height: 10),

                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _ResultChip(
                      label:
                          'Pass $passed',
                    ),
                    _ResultChip(
                      label:
                          'Advisory $advisories',
                    ),
                    _ResultChip(
                      label:
                          'Defect $failed',
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// =============================================================================
// RESULT CHIP
// =============================================================================

class _ResultChip extends StatelessWidget {
  final String label;

  const _ResultChip({
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    final scheme =
        Theme.of(context).colorScheme;

    return Container(
      padding:
          const EdgeInsets.symmetric(
        horizontal: 11,
        vertical: 7,
      ),
      decoration: BoxDecoration(
        color:
            scheme.surfaceContainerHighest,
        borderRadius:
            BorderRadius.circular(20),
      ),
      child: Text(
        label,
        style: const TextStyle(
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

// =============================================================================
// SUMMARY CHIP
// =============================================================================

class _SummaryChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _SummaryChip({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    final scheme =
        Theme.of(context).colorScheme;

    return Container(
      padding:
          const EdgeInsets.symmetric(
        horizontal: 13,
        vertical: 10,
      ),
      decoration: BoxDecoration(
        color:
            scheme.surfaceContainerHighest,
        borderRadius:
            BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize:
            MainAxisSize.min,
        children: [
          Icon(
            icon,
            size: 19,
            color: scheme.primary,
          ),
          const SizedBox(width: 7),
          Text(
            '$label: ',
            style: const TextStyle(
              fontWeight:
                  FontWeight.w600,
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              fontWeight:
                  FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}