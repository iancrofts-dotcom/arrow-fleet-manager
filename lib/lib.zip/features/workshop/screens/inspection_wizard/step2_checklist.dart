import 'package:flutter/material.dart';

import '../../models/inspection_checklist_item.dart';
import '../../models/inspection_wizard_data.dart';
import '../../services/checklist_template_service.dart';
import '../../widgets/checklist_item_card.dart';

class Step2Checklist extends StatefulWidget {
  final InspectionWizardData data;
  final VoidCallback onNext;
  final VoidCallback onPrevious;

  const Step2Checklist({
    super.key,
    required this.data,
    required this.onNext,
    required this.onPrevious,
  });

  @override
  State<Step2Checklist> createState() => _Step2ChecklistState();
}

class _Step2ChecklistState extends State<Step2Checklist> {
  final ChecklistTemplateService _templateService =
    ChecklistTemplateService();

  @override
  void initState() {
    super.initState();
  
    _loadChecklist();
  }

  void _loadChecklist() {
    if (widget.data.checklistItems.isEmpty) {
      widget.data.checklistItems = _templateService.getDefaultTemplate();
    }
  }

  void _updateChecklistItem(InspectionChecklistItem item) {
    setState(() {
      final index = widget.data.checklistItems.indexWhere(
        (existingItem) => existingItem.id == item.id,
      );

      if (index != -1) {
        widget.data.checklistItems[index] = item;
      }
    });
  }

  @override
    Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: widget.data.checklistItems.length,
            separatorBuilder: (_, _) => const SizedBox(height: 16),
            itemBuilder: (context, index) {
              return ChecklistItemCard(
                item: widget.data.checklistItems[index],
                onChanged: _updateChecklistItem,
              );
            },
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              OutlinedButton.icon(
                onPressed: widget.onPrevious,
                icon: const Icon(Icons.arrow_back),
                label: const Text('Back'),
              ),
              const Spacer(),
              FilledButton.icon(
                onPressed: widget.onNext,
                icon: const Icon(Icons.arrow_forward),
                label: const Text('Continue'),
              ),
            ],
          ),
        ),
      ],
    );
  }
}