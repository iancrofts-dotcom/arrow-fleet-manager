import 'package:flutter/material.dart';

class Step2Checklist extends StatelessWidget {
  const Step2Checklist({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        'Inspection Checklist',
        style: TextStyle(
          fontSize: 28,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}