import 'package:flutter/material.dart';

class Step4Repairs extends StatelessWidget {
  const Step4Repairs({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        'Repair Review',
        style: TextStyle(
          fontSize: 28,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}