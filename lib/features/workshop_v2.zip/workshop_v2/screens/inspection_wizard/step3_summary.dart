import 'package:flutter/material.dart';

class Step3Summary extends StatelessWidget {
  const Step3Summary({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        'Inspection Summary',
        style: TextStyle(
          fontSize: 28,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}