import 'package:flutter/material.dart';

class Step1VehicleDetails extends StatelessWidget {
  const Step1VehicleDetails({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        'Vehicle Details',
        style: TextStyle(
          fontSize: 28,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}