import 'package:flutter/material.dart';

class Step5Signoff extends StatelessWidget {
  const Step5Signoff({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        'Sign-off',
        style: TextStyle(
          fontSize: 28,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}