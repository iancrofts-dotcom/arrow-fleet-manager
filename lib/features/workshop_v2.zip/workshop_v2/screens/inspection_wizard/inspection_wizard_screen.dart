import 'package:flutter/material.dart';

import '../../core/wizard_controller.dart';
import '../../widgets/wizard_header.dart';
import '../../widgets/wizard_navigation.dart';
import '../../widgets/wizard_progress.dart';

import 'step1_vehicle_details.dart';
import 'step2_checklist.dart';
import 'step3_summary.dart';
import 'step4_repairs.dart';
import 'step5_signoff.dart';

class InspectionWizardScreen extends StatefulWidget {
  const InspectionWizardScreen({super.key});

  @override
  State<InspectionWizardScreen> createState() =>
      _InspectionWizardScreenState();
}

class _InspectionWizardScreenState
    extends State<InspectionWizardScreen> {
  late final WizardController controller;

  static const int totalSteps = 5;

  final List<String> stepTitles = const [
    'Vehicle Details',
    'Inspection Checklist',
    'Inspection Summary',
    'Repair Review',
    'Sign-off',
  ];

  @override
  void initState() {
    super.initState();
    controller = WizardController(totalSteps: totalSteps);
    controller.addListener(_onControllerChanged);
  }

  @override
  void dispose() {
    controller.removeListener(_onControllerChanged);
    controller.dispose();
    super.dispose();
  }

  void _onControllerChanged() {
    if (mounted) {
      setState(() {});
    }
  }

  Widget _buildCurrentStep() {
    switch (controller.currentStep) {
      case 0:
        return const Step1VehicleDetails();

      case 1:
        return const Step2Checklist();

      case 2:
        return const Step3Summary();

      case 3:
        return const Step4Repairs();

      case 4:
        return const Step5Signoff();

      default:
        return const SizedBox.shrink();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Workshop Inspection V2'),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              WizardHeader(
                title: stepTitles[controller.currentStep],
                currentStep: controller.currentStep + 1,
                totalSteps: totalSteps,
              ),

              const SizedBox(height: 16),

              WizardProgress(
                progress: controller.progress,
              ),

              const SizedBox(height: 24),

              Expanded(
  child: Container(
    color: Colors.green,
    child: const Center(
      child: Text(
        'STEP HOST',
        style: TextStyle(
          fontSize: 32,
          color: Colors.white,
          fontWeight: FontWeight.bold,
        ),
      ),
    ),
  ),
),

              const SizedBox(height: 16),

              WizardNavigation(
                isFirstStep: controller.isFirstStep,
                isLastStep: controller.isLastStep,
                onPrevious: () {
                  controller.previous();
                },
                onNext: () {
                  controller.next();
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}